# Event Template

A simple template that I've created with flex-box

**NOTE: UNDER HEAVY CONSTRUCTION**

View Template Here: [Event Template](http://avestura.dev/EventTemplate/)
